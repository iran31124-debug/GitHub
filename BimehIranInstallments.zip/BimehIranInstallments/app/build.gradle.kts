plugins { id("com.android.application") }

android { namespace = "com.iran31124.bimeh"; compileSdk = 35
    defaultConfig { applicationId = "com.iran31124.bimeh"; minSdk = 23; targetSdk = 35; versionCode = 1; versionName = "1.0" }
}
